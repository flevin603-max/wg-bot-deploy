from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # Telegram
    bot_token: str
    admin_ids: str  # "111,222" -> parsed below

    # Database
    database_url: str

    # WireGuard
    wg_interface: str = "wg0"
    wg_config_path: str = "/etc/wireguard/wg0.conf"
    wg_server_public_endpoint: str
    wg_server_public_key: str
    wg_client_dns: str = "1.1.1.1"
    wg_client_subnet: str = "10.66.66.0/24"

    # Timeweb Cloud
    timeweb_token: str = ""
    timeweb_server_id: str = ""

    # Web app
    webapp_host: str = "0.0.0.0"
    webapp_port: int = 8000
    webapp_public_url: str = ""
    webapp_secret_key: str = "change_me"

    # Metrics
    metrics_collect_interval_seconds: int = 60
    daily_report_hour_utc: int = 6

    @property
    def admin_ids_list(self) -> list[int]:
        return [int(x.strip()) for x in self.admin_ids.split(",") if x.strip()]


settings = Settings()
