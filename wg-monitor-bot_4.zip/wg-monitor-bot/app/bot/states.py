from aiogram.fsm.state import State, StatesGroup


class RequestStates(StatesGroup):
    waiting_label = State()


class JoinStates(StatesGroup):
    waiting_code = State()
    waiting_label = State()
