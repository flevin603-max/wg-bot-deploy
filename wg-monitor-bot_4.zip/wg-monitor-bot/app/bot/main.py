import asyncio
import logging

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from apscheduler.schedulers.asyncio import AsyncIOScheduler

from app.bot.handlers import admin, user
from app.bot.middlewares.auth import AuthMiddleware
from app.config import settings
from app.database.engine import init_db
from app.services import metrics
from app.services.timeweb_api import timeweb_client

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def send_daily_report(bot: Bot) -> None:
    snapshot = await metrics.get_current_snapshot()
    periods = await metrics.get_period_stats()
    try:
        balance = await timeweb_client.get_balance()
        balance_line = f"💰 Баланс: {balance:.2f} ₽"
    except Exception as e:  # noqa: BLE001
        balance_line = f"💰 Баланс: ошибка ({e})"

    lines = [
        "📅 <b>Ежедневный отчёт</b>",
        f"CPU сейчас: {snapshot['cpu_percent']}% · RAM: {snapshot['ram_percent']}%",
    ]
    for p in periods:
        lines.append(f"{p.label}: CPU avg {p.avg_cpu}% · RAM avg {p.avg_ram}%")
    lines.append(balance_line)

    text = "\n".join(lines)
    for admin_id in settings.admin_ids_list:
        try:
            await bot.send_message(admin_id, text)
        except Exception:  # noqa: BLE001
            logger.exception("Не удалось отправить отчёт админу %s", admin_id)


async def main() -> None:
    await init_db()

    bot = Bot(token=settings.bot_token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher()

    dp.update.middleware(AuthMiddleware())
    dp.include_router(admin.router)
    dp.include_router(user.router)

    scheduler = AsyncIOScheduler(timezone="UTC")
    scheduler.add_job(metrics.collect_snapshot, "interval", seconds=settings.metrics_collect_interval_seconds)
    scheduler.add_job(send_daily_report, "cron", hour=settings.daily_report_hour_utc, args=[bot])
    scheduler.start()

    logger.info("Бот запущен")
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
