from datetime import datetime, timezone

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import BufferedInputFile, InlineKeyboardButton, InlineKeyboardMarkup, Message
from sqlalchemy import select

from app.bot.middlewares.auth import IsUser
from app.bot.states import JoinStates, RequestStates
from app.config import settings
from app.database.engine import async_session
from app.database.models import InviteCode, KeyRequest, User, UserRole, WGPeer
from app.services import wireguard

router = Router()
router.message.filter(IsUser())


@router.message(Command("join"))
async def cmd_join(message: Message, db_user: User, state: FSMContext) -> None:
    """Использование: /join XXXX-XXXX [название устройства].
    Если код не передан аргументом — спросим отдельным сообщением.
    Если название не передано — тоже спросим отдельно (можно писать своими словами)."""
    parts = message.text.split(maxsplit=2)

    if len(parts) < 2:
        await state.set_state(JoinStates.waiting_code)
        await message.answer("Пришли код-приглашение (его даёт админ), например: <code>ABCD-1234</code>")
        return

    code_str = parts[1].strip().upper()
    if len(parts) > 2:
        await _issue_key_by_code(message, db_user, code_str, parts[2].strip())
    else:
        await state.update_data(code=code_str)
        await state.set_state(JoinStates.waiting_label)
        await message.answer("Как назвать это устройство? Например: <i>Ноутбук Полины</i>")


@router.message(JoinStates.waiting_code)
async def join_got_code(message: Message, state: FSMContext) -> None:
    code_str = message.text.strip().upper()
    await state.update_data(code=code_str)
    await state.set_state(JoinStates.waiting_label)
    await message.answer("Как назвать это устройство? Например: <i>Ноутбук Полины</i>")


@router.message(JoinStates.waiting_label)
async def join_got_label(message: Message, db_user: User, state: FSMContext) -> None:
    data = await state.get_data()
    await state.clear()
    await _issue_key_by_code(message, db_user, data["code"], message.text.strip())


async def _issue_key_by_code(message: Message, db_user: User, code_str: str, label: str) -> None:
    async with async_session() as session:
        result = await session.execute(select(InviteCode).where(InviteCode.code == code_str))
        code = result.scalar_one_or_none()

        if code is None:
            await message.answer("❌ Такого кода нет. Проверь, что скопировал без опечаток.")
            return
        if code.revoked:
            await message.answer("❌ Этот код отозван.")
            return
        if code.used_at is not None:
            await message.answer("❌ Этот код уже использован.")
            return
        if code.expires_at and code.expires_at < datetime.now(timezone.utc):
            await message.answer("❌ Срок действия этого кода истёк.")
            return

        try:
            peer_data = await wireguard.add_peer(label)
        except Exception as e:  # noqa: BLE001
            await message.answer(
                f"⚠️ Код верный, но не получилось создать ключ на сервере:\n<code>{e}</code>\n\n"
                "Код остался неиспользованным, можешь попробовать ещё раз чуть позже. "
                "Админу тоже пришло уведомление."
            )
            for admin_id in settings.admin_ids_list:
                try:
                    await message.bot.send_message(
                        admin_id, f"🔴 Ошибка выдачи ключа по коду {code_str} для {message.from_user.full_name}:\n{e}"
                    )
                except Exception:  # noqa: BLE001
                    pass
            return

        wg_peer = WGPeer(
            owner_id=db_user.id,
            label=label,
            public_key=peer_data["public_key"],
            private_key=peer_data["private_key"],
            address=peer_data["address"],
        )
        session.add(wg_peer)

        code.used_by_id = db_user.id
        code.used_at = datetime.now(timezone.utc)
        await session.commit()

        config_text = wireguard.build_client_config(peer_data["private_key"], peer_data["address"])

    safe_label = "".join(c if c.isalnum() else "_" for c in label)[:40] or "wg-client"
    conf_file = BufferedInputFile(config_text.encode(), filename=f"{safe_label}.conf")
    qr_png = wireguard.build_qr_png(config_text)
    qr_photo = BufferedInputFile(qr_png, filename=f"{safe_label}_qr.png")

    await message.answer("🎉 Ключ выдан! Файл ниже — открой его приложением WireGuard, либо отсканируй QR.")
    await message.answer_document(conf_file, caption=f"Конфиг: {label}")
    await message.answer_photo(qr_photo, caption="Отсканируй в приложении WireGuard (кнопка «+» → «Сканировать QR»)")

    for admin_id in settings.admin_ids_list:
        try:
            await message.bot.send_message(
                admin_id,
                f"ℹ️ {message.from_user.full_name} (id {message.from_user.id}) получил ключ «{label}» "
                f"по коду {code_str}.",
            )
        except Exception:  # noqa: BLE001
            pass


@router.message(Command("start"))
async def cmd_start(message: Message, db_user: User) -> None:
    role_label = "администратор" if db_user.role == UserRole.admin else "пользователь"
    text = (
        f"Привет, {message.from_user.first_name}! Ты авторизован как <b>{role_label}</b>.\n\n"
        "Доступные команды:\n"
        "/mykeys — мои WireGuard-ключи и статус\n"
        "/join КОД — получить ключ по коду-приглашению (сразу, без ожидания)\n"
        "/request — запросить новый ключ (с одобрением админа)\n"
    )
    if db_user.role == UserRole.admin:
        text += (
            "\nАдмин-команды:\n"
            "/stats — нагрузка сервера + баланс\n"
            "/peers — список всех подключений\n"
            "/managekeys — отключить/включить обратно любой ключ\n"
            "/resync — принудительно применить конфиг на живой интерфейс\n"
            "/requests — заявки на новые ключи\n"
            "/gencode [заметка] [часы] — создать код-приглашение\n"
            "/codes — список кодов и их статус\n"
            "/revokecode КОД — отозвать код\n"
        )
    if settings.webapp_public_url:
        kb = InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(text="📊 Открыть панель", web_app={"url": settings.webapp_public_url})]
            ]
        )
        await message.answer(text, reply_markup=kb)
    else:
        await message.answer(text)


@router.message(Command("mykeys"))
async def cmd_mykeys(message: Message, db_user: User) -> None:
    async with async_session() as session:
        peers = (
            await session.execute(
                select(WGPeer).where(WGPeer.owner_id == db_user.id, WGPeer.is_active.is_(True))
            )
        ).scalars().all()

    if not peers:
        await message.answer("У тебя пока нет активных ключей. Используй /request, чтобы запросить.")
        return

    statuses = {s.public_key: s for s in await wireguard.get_wg_status()}
    lines = ["🔑 <b>Твои ключи:</b>\n"]
    for peer in peers:
        status = statuses.get(peer.public_key)
        online = status.is_online if status else False
        icon = "🟢 онлайн" if online else "⚪️ офлайн"
        lines.append(f"• {peer.label} — {icon}")
    await message.answer("\n".join(lines))


@router.message(Command("request"))
async def cmd_request_key(message: Message, db_user: User, state: FSMContext) -> None:
    parts = message.text.split(maxsplit=1)
    if len(parts) > 1:
        await _create_key_request(message, db_user, parts[1].strip())
    else:
        await state.set_state(RequestStates.waiting_label)
        await message.answer("Как назвать устройство, для которого нужен доступ? Например: <i>Айфон мамы</i>")


@router.message(RequestStates.waiting_label)
async def request_got_label(message: Message, db_user: User, state: FSMContext) -> None:
    await state.clear()
    await _create_key_request(message, db_user, message.text.strip())


async def _create_key_request(message: Message, db_user: User, label: str) -> None:
    async with async_session() as session:
        req = KeyRequest(requester_id=db_user.id, label=label)
        session.add(req)
        await session.commit()
        await session.refresh(req)

    await message.answer(f"Заявка #{req.id} отправлена админу на одобрение. Как только одобрят — пришлю конфиг.")

    for admin_id in settings.admin_ids_list:
        try:
            await message.bot.send_message(
                admin_id, f"🆕 Новая заявка #{req.id} на ключ: «{label}»\nПосмотреть: /requests"
            )
        except Exception:  # noqa: BLE001
            pass
