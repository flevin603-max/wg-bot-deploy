import secrets
from datetime import datetime, timedelta, timezone

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import BufferedInputFile, CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message
from sqlalchemy import select

from app.bot.middlewares.auth import IsAdmin
from app.database.engine import async_session
from app.database.models import InviteCode, KeyRequest, KeyRequestStatus, User, WGPeer
from app.services import metrics, wireguard
from app.services.timeweb_api import timeweb_client

router = Router()
router.message.filter(IsAdmin())
router.callback_query.filter(IsAdmin())


def _generate_code() -> str:
    # 8 символов вида XXXX-XXXX, без похожих друг на друга символов (0/O, 1/I)
    alphabet = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"
    raw = "".join(secrets.choice(alphabet) for _ in range(8))
    return f"{raw[:4]}-{raw[4:]}"


@router.message(Command("gencode"))
async def cmd_gencode(message: Message, db_user: User) -> None:
    """Использование: /gencode [заметка] [срок_в_часах]
    Например: /gencode Полина 48  -> код проживёт 48 часов
    Без срока — код бессрочный (пока не использован или не отозван)."""
    parts = message.text.split(maxsplit=2)[1:]  # всё, что после "/gencode"
    note = None
    expires_at = None

    if parts:
        # если последний токен — число, считаем это часами жизни кода
        if parts[-1].isdigit():
            expires_at = datetime.now(timezone.utc) + timedelta(hours=int(parts[-1]))
            parts = parts[:-1]
        if parts:
            note = " ".join(parts)

    code = _generate_code()
    async with async_session() as session:
        session.add(
            InviteCode(code=code, note=note, created_by=db_user.telegram_id, expires_at=expires_at)
        )
        await session.commit()

    expiry_line = f"\n⏳ Действует до: {expires_at.strftime('%d.%m %H:%M')} UTC" if expires_at else "\n⏳ Бессрочный"
    note_line = f"\n📝 Заметка: {note}" if note else ""
    await message.answer(
        f"🎟 Код-приглашение создан:\n\n<code>{code}</code>{note_line}{expiry_line}\n\n"
        f"Отправь его тому, кому нужен доступ. Он вводит в боте:\n/join {code}"
    )


@router.message(Command("codes"))
async def cmd_list_codes(message: Message) -> None:
    async with async_session() as session:
        codes = (await session.execute(select(InviteCode).order_by(InviteCode.created_at.desc()))).scalars().all()

    if not codes:
        await message.answer("Кодов пока нет. Создать: /gencode [заметка] [часы]")
        return

    lines = ["🎟 <b>Коды-приглашения:</b>\n"]
    for c in codes:
        if c.revoked:
            status = "🚫 отозван"
        elif c.used_at:
            status = "✅ использован"
        elif c.expires_at and c.expires_at < datetime.now(timezone.utc):
            status = "⌛ истёк"
        else:
            status = "🟢 активен"
        note = f" — {c.note}" if c.note else ""
        lines.append(f"<code>{c.code}</code>{note} · {status}")

    await message.answer("\n".join(lines))


@router.message(Command("revokecode"))
async def cmd_revoke_code(message: Message) -> None:
    parts = message.text.split(maxsplit=1)
    if len(parts) < 2:
        await message.answer("Использование: /revokecode XXXX-XXXX")
        return

    code_str = parts[1].strip().upper()
    async with async_session() as session:
        result = await session.execute(select(InviteCode).where(InviteCode.code == code_str))
        code = result.scalar_one_or_none()
        if code is None:
            await message.answer("Код не найден.")
            return
        code.revoked = True
        await session.commit()

    await message.answer(f"Код {code_str} отозван.")


@router.message(Command("stats"))
async def cmd_stats(message: Message) -> None:
    snapshot = await metrics.get_current_snapshot()
    periods = await metrics.get_period_stats()

    lines = [
        "📊 <b>Состояние сервера сейчас</b>",
        f"CPU: {snapshot['cpu_percent']}%",
        f"RAM: {snapshot['ram_percent']}% ({snapshot['ram_used_mb']:.0f}/{snapshot['ram_total_mb']:.0f} MB)",
        f"Диск: {snapshot['disk_percent']}%",
        f"Аптайм: {snapshot['uptime_hours']} ч",
        "",
        "📈 <b>Средняя/пиковая нагрузка</b>",
    ]
    for p in periods:
        lines.append(f"{p.label}: CPU avg {p.avg_cpu}% / max {p.max_cpu}% · RAM avg {p.avg_ram}% / max {p.max_ram}%")

    try:
        balance = await timeweb_client.get_balance()
        lines.append(f"\n💰 Баланс Timeweb: {balance:.2f} ₽")
    except Exception as e:  # noqa: BLE001
        lines.append(f"\n💰 Баланс Timeweb: ошибка получения ({e})")

    await message.answer("\n".join(lines))


@router.message(Command("managekeys"))
async def cmd_manage_keys(message: Message) -> None:
    async with async_session() as session:
        peers = (await session.execute(select(WGPeer).order_by(WGPeer.created_at.desc()))).scalars().all()

    if not peers:
        await message.answer("Ключей пока нет.")
        return

    for peer in peers:
        state_icon = "🟢 активен" if peer.is_active else "🔴 отключён"
        btn_text = "🚫 Отключить" if peer.is_active else "✅ Включить обратно"
        kb = InlineKeyboardMarkup(
            inline_keyboard=[[InlineKeyboardButton(text=btn_text, callback_data=f"peer_toggle:{peer.id}")]]
        )
        await message.answer(f"{peer.label} — {state_icon}", reply_markup=kb)


@router.callback_query(F.data.startswith("peer_toggle:"))
async def toggle_peer(callback: CallbackQuery) -> None:
    peer_id = int(callback.data.split(":")[1])
    async with async_session() as session:
        peer = await session.get(WGPeer, peer_id)
        if peer is None:
            await callback.answer("Ключ не найден.")
            return

        try:
            if peer.is_active:
                await wireguard.remove_peer(peer.public_key)
                peer.is_active = False
                peer.revoked_at = datetime.now(timezone.utc)
                new_text = f"{peer.label} — 🔴 отключён"
                new_btn = "✅ Включить обратно"
            else:
                await wireguard.reenable_peer(peer.public_key, peer.address, peer.label)
                peer.is_active = True
                peer.revoked_at = None
                new_text = f"{peer.label} — 🟢 активен"
                new_btn = "🚫 Отключить"
            await session.commit()
        except Exception as e:  # noqa: BLE001
            await callback.answer("Ошибка, смотри сообщение ниже", show_alert=True)
            await callback.message.answer(
                f"🔴 Не получилось изменить статус ключа «{peer.label}»:\n<code>{e}</code>"
            )
            return

    kb = InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text=new_btn, callback_data=f"peer_toggle:{peer_id}")]]
    )
    await callback.message.edit_text(new_text, reply_markup=kb)
    await callback.answer("Готово")


@router.message(Command("resync"))
async def cmd_resync(message: Message) -> None:
    """На случай если peer записан в конфиг, но не применился на живом интерфейсе."""
    try:
        dump = await wireguard.force_resync()
    except Exception as e:  # noqa: BLE001
        await message.answer(f"🔴 Не получилось пересинхронизировать:\n<code>{e}</code>")
        return

    peer_count = len(dump.strip().splitlines()) - 1  # первая строка — сам интерфейс
    await message.answer(f"✅ Пересинхронизировано. Активных пиров на интерфейсе: {peer_count}")


@router.message(Command("peers"))
async def cmd_peers(message: Message) -> None:
    statuses = await wireguard.get_wg_status()
    async with async_session() as session:
        db_peers = (await session.execute(select(WGPeer).where(WGPeer.is_active.is_(True)))).scalars().all()

    by_pubkey = {p.public_key: p for p in db_peers}
    online = sum(1 for s in statuses if s.is_online)

    lines = [f"🔑 <b>WireGuard: {len(statuses)} клиентов, {online} онлайн</b>\n"]
    for s in statuses:
        peer = by_pubkey.get(s.public_key)
        label = peer.label if peer else s.public_key[:8] + "…"
        status_icon = "🟢" if s.is_online else "⚪️"
        lines.append(f"{status_icon} {label} — ↓{s.transfer_rx_mb:.0f}MB ↑{s.transfer_tx_mb:.0f}MB")

    await message.answer("\n".join(lines))


@router.message(Command("requests"))
async def cmd_pending_requests(message: Message) -> None:
    async with async_session() as session:
        pending = (
            await session.execute(select(KeyRequest).where(KeyRequest.status == KeyRequestStatus.pending))
        ).scalars().all()

    if not pending:
        await message.answer("Нет заявок на новые ключи.")
        return

    for req in pending:
        kb = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(text="✅ Одобрить", callback_data=f"req_approve:{req.id}"),
                    InlineKeyboardButton(text="❌ Отклонить", callback_data=f"req_reject:{req.id}"),
                ]
            ]
        )
        await message.answer(f"Заявка #{req.id}: «{req.label}»", reply_markup=kb)


@router.callback_query(F.data.startswith("req_approve:"))
async def approve_request(callback: CallbackQuery, db_user: User) -> None:
    req_id = int(callback.data.split(":")[1])
    async with async_session() as session:
        req = await session.get(KeyRequest, req_id)
        if req is None or req.status != KeyRequestStatus.pending:
            await callback.answer("Заявка уже обработана.")
            return

        requester = await session.get(User, req.requester_id)

        try:
            peer_data = await wireguard.add_peer(req.label)
        except Exception as e:  # noqa: BLE001
            await callback.answer("Ошибка при создании ключа, смотри сообщение ниже", show_alert=True)
            await callback.message.answer(
                f"🔴 Не получилось выдать ключ по заявке #{req_id}:\n<code>{e}</code>\n\n"
                "Заявка осталась в статусе pending, можно попробовать одобрить ещё раз."
            )
            return

        wg_peer = WGPeer(
            owner_id=requester.id,
            label=req.label,
            public_key=peer_data["public_key"],
            private_key=peer_data["private_key"],
            address=peer_data["address"],
        )
        session.add(wg_peer)

        req.status = KeyRequestStatus.approved
        req.resolved_by = db_user.telegram_id

        req.resolved_at = datetime.now(timezone.utc)
        await session.commit()

        config_text = wireguard.build_client_config(peer_data["private_key"], peer_data["address"])

    await callback.message.edit_text(f"✅ Заявка #{req_id} одобрена, ключ выдан.")

    safe_label = "".join(c if c.isalnum() else "_" for c in req.label)[:40] or "wg-client"
    conf_file = BufferedInputFile(config_text.encode(), filename=f"{safe_label}.conf")
    qr_png = wireguard.build_qr_png(config_text)
    qr_photo = BufferedInputFile(qr_png, filename=f"{safe_label}_qr.png")

    try:
        await callback.bot.send_message(requester.telegram_id, "🎉 Твой ключ готов! Файл ниже, либо отсканируй QR.")
        await callback.bot.send_document(requester.telegram_id, conf_file, caption=f"Конфиг: {req.label}")
        await callback.bot.send_photo(
            requester.telegram_id, qr_photo, caption="Отсканируй в приложении WireGuard (кнопка «+» → «Сканировать QR»)"
        )
    except Exception as e:  # noqa: BLE001
        await callback.message.answer(
            f"⚠️ Ключ создан на сервере, но не удалось отправить его пользователю в Telegram:\n<code>{e}</code>"
        )
    await callback.answer()


@router.callback_query(F.data.startswith("req_reject:"))
async def reject_request(callback: CallbackQuery, db_user: User) -> None:
    req_id = int(callback.data.split(":")[1])
    async with async_session() as session:
        req = await session.get(KeyRequest, req_id)
        if req is None or req.status != KeyRequestStatus.pending:
            await callback.answer("Заявка уже обработана.")
            return
        req.status = KeyRequestStatus.rejected
        req.resolved_by = db_user.telegram_id

        req.resolved_at = datetime.now(timezone.utc)
        requester_id = req.requester_id
        requester = await session.get(User, requester_id)
        await session.commit()

    await callback.message.edit_text(f"❌ Заявка #{req_id} отклонена.")
    await callback.bot.send_message(requester.telegram_id, "К сожалению, твоя заявка на ключ отклонена.")
    await callback.answer()
