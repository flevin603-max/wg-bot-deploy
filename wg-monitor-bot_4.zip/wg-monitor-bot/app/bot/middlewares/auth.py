from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware
from aiogram.filters import Filter
from aiogram.types import TelegramObject, User as TgUser
from sqlalchemy import select

from app.config import settings
from app.database.engine import async_session
from app.database.models import User, UserRole


class AuthMiddleware(BaseMiddleware):
    """Подтягивает/создаёт User в БД и кладёт его в data['db_user'] перед каждым апдейтом."""

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        tg_user: TgUser | None = data.get("event_from_user")
        if tg_user is None:
            return await handler(event, data)

        async with async_session() as session:
            result = await session.execute(select(User).where(User.telegram_id == tg_user.id))
            db_user = result.scalar_one_or_none()

            role = UserRole.admin if tg_user.id in settings.admin_ids_list else UserRole.user

            if db_user is None:
                db_user = User(
                    telegram_id=tg_user.id,
                    username=tg_user.username,
                    full_name=tg_user.full_name,
                    role=role,
                )
                session.add(db_user)
                await session.commit()
                await session.refresh(db_user)
            elif db_user.role != role:
                # если id добавили/убрали из ADMIN_IDS — синхронизируем роль
                db_user.role = role
                await session.commit()

            data["db_user"] = db_user

        return await handler(event, data)


class IsAdmin(Filter):
    """Пропускает апдейт, только если AuthMiddleware пометил пользователя как admin."""

    async def __call__(self, event: TelegramObject, db_user: User) -> bool:
        return db_user.role == UserRole.admin


class IsUser(Filter):
    """Пропускает любого зарегистрированного пользователя (админа тоже — админ может и как юзер)."""

    async def __call__(self, event: TelegramObject, db_user: User) -> bool:
        return db_user is not None
