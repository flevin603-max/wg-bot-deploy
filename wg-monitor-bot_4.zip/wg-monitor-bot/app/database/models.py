import enum
from datetime import datetime

from sqlalchemy import BigInteger, Boolean, DateTime, Enum, Float, ForeignKey, Integer, String, func
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


class UserRole(str, enum.Enum):
    admin = "admin"
    user = "user"


class KeyRequestStatus(str, enum.Enum):
    pending = "pending"
    approved = "approved"
    rejected = "rejected"


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    telegram_id: Mapped[int] = mapped_column(BigInteger, unique=True, index=True)
    username: Mapped[str | None] = mapped_column(String(255), nullable=True)
    full_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    role: Mapped[UserRole] = mapped_column(Enum(UserRole), default=UserRole.user)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    peers: Mapped[list["WGPeer"]] = relationship(back_populates="owner")


class WGPeer(Base):
    """Один WireGuard-клиент (peer), привязанный к пользователю."""

    __tablename__ = "wg_peers"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    owner_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    label: Mapped[str] = mapped_column(String(255))  # например "Полина iPhone"
    public_key: Mapped[str] = mapped_column(String(64), unique=True)
    private_key: Mapped[str] = mapped_column(String(64))  # храним, чтобы переотдать конфиг при необходимости
    address: Mapped[str] = mapped_column(String(32))  # 10.66.66.5/32
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    owner: Mapped["User"] = relationship(back_populates="peers")


class KeyRequest(Base):
    """Заявка пользователя на новый ключ, требует одобрения админа."""

    __tablename__ = "key_requests"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    requester_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    label: Mapped[str] = mapped_column(String(255))
    status: Mapped[KeyRequestStatus] = mapped_column(Enum(KeyRequestStatus), default=KeyRequestStatus.pending)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    resolved_by: Mapped[int | None] = mapped_column(BigInteger, nullable=True)  # telegram_id админа


class InviteCode(Base):
    """Одноразовый код-приглашение: пользователь вводит его в /join и сразу
    получает ключ без ручного одобрения админом."""

    __tablename__ = "invite_codes"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(16), unique=True, index=True)
    note: Mapped[str | None] = mapped_column(String(255), nullable=True)  # для кого код (заметка админа)
    created_by: Mapped[int] = mapped_column(BigInteger)  # telegram_id админа
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    revoked: Mapped[bool] = mapped_column(Boolean, default=False)

    used_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class ServerMetric(Base):
    """Снепшот нагрузки сервера, пишется раз в METRICS_COLLECT_INTERVAL_SECONDS."""

    __tablename__ = "server_metrics"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ts: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), index=True)
    cpu_percent: Mapped[float] = mapped_column(Float)
    ram_percent: Mapped[float] = mapped_column(Float)
    ram_used_mb: Mapped[float] = mapped_column(Float)
    ram_total_mb: Mapped[float] = mapped_column(Float)
    disk_percent: Mapped[float] = mapped_column(Float)
    net_sent_mb: Mapped[float] = mapped_column(Float)
    net_recv_mb: Mapped[float] = mapped_column(Float)
