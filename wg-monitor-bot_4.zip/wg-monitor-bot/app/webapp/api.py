"""
Backend для Telegram Mini App (WebApp).

Проверка подлинности запроса делается через Telegram initData (HMAC подписью
BOT_TOKEN) — см. validate_init_data(). Без валидной initData отдаём 401,
чтобы кто попало не мог достучаться до API по прямой ссылке.
"""

import hashlib
import hmac
from urllib.parse import parse_qsl

from fastapi import FastAPI, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from sqlalchemy import select

from app.config import settings
from app.database.engine import async_session
from app.database.models import User, UserRole, WGPeer
from app.services import metrics, wireguard
from app.services.timeweb_api import timeweb_client

app = FastAPI(title="WG Monitor WebApp API")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


def validate_init_data(init_data: str) -> dict:
    """Проверяет подпись Telegram WebApp initData и возвращает распарсенные поля."""
    parsed = dict(parse_qsl(init_data))
    received_hash = parsed.pop("hash", None)
    if not received_hash:
        raise HTTPException(401, "no hash in initData")

    data_check_string = "\n".join(f"{k}={v}" for k, v in sorted(parsed.items()))
    secret_key = hmac.new(b"WebAppData", settings.bot_token.encode(), hashlib.sha256).digest()
    calculated_hash = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()

    if calculated_hash != received_hash:
        raise HTTPException(401, "invalid initData signature")
    return parsed


async def _get_user_from_init_data(x_telegram_init_data: str) -> User:
    import json

    parsed = validate_init_data(x_telegram_init_data)
    tg_user = json.loads(parsed["user"])
    async with async_session() as session:
        result = await session.execute(select(User).where(User.telegram_id == tg_user["id"]))
        db_user = result.scalar_one_or_none()
        if db_user is None:
            raise HTTPException(404, "user not registered, open the bot with /start first")
        return db_user


@app.get("/api/me")
async def get_me(x_telegram_init_data: str = Header(...)) -> dict:
    db_user = await _get_user_from_init_data(x_telegram_init_data)
    return {"telegram_id": db_user.telegram_id, "role": db_user.role.value, "username": db_user.username}


@app.get("/api/stats")
async def get_stats(x_telegram_init_data: str = Header(...)) -> dict:
    db_user = await _get_user_from_init_data(x_telegram_init_data)
    if db_user.role != UserRole.admin:
        raise HTTPException(403, "admins only")

    snapshot = await metrics.get_current_snapshot()
    periods = await metrics.get_period_stats()
    try:
        balance = await timeweb_client.get_balance()
    except Exception:  # noqa: BLE001
        balance = None

    return {
        "current": snapshot,
        "periods": [p.__dict__ for p in periods],
        "balance": balance,
    }


@app.get("/api/peers")
async def get_peers(x_telegram_init_data: str = Header(...)) -> dict:
    db_user = await _get_user_from_init_data(x_telegram_init_data)
    if db_user.role != UserRole.admin:
        raise HTTPException(403, "admins only")

    statuses = {s.public_key: s for s in await wireguard.get_wg_status()}
    async with async_session() as session:
        peers = (await session.execute(select(WGPeer).where(WGPeer.is_active.is_(True)))).scalars().all()

    return {
        "peers": [
            {
                "label": p.label,
                "online": statuses[p.public_key].is_online if p.public_key in statuses else False,
                "rx_mb": statuses[p.public_key].transfer_rx_mb if p.public_key in statuses else 0,
                "tx_mb": statuses[p.public_key].transfer_tx_mb if p.public_key in statuses else 0,
            }
            for p in peers
        ]
    }


@app.get("/api/my-keys")
async def get_my_keys(x_telegram_init_data: str = Header(...)) -> dict:
    db_user = await _get_user_from_init_data(x_telegram_init_data)
    statuses = {s.public_key: s for s in await wireguard.get_wg_status()}
    async with async_session() as session:
        peers = (
            await session.execute(
                select(WGPeer).where(WGPeer.owner_id == db_user.id, WGPeer.is_active.is_(True))
            )
        ).scalars().all()

    return {
        "peers": [
            {"label": p.label, "online": statuses[p.public_key].is_online if p.public_key in statuses else False}
            for p in peers
        ]
    }


app.mount("/", StaticFiles(directory="app/webapp/static", html=True), name="static")
