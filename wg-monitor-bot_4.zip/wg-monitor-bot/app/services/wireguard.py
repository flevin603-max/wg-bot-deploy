"""
Работа с WireGuard.

ВАЖНО про права: команды wg/wg-quick требуют root. Бот-процесс либо запускается
от root в контейнере с network_mode: host и смонтированным /etc/wireguard,
либо (безопаснее) дергает эти команды через отдельный root-скрипт по sudo с
NOPASSWD для конкретных команд (см. README, раздел "Права для WireGuard").
"""

import asyncio
import ipaddress
import re
from dataclasses import dataclass
from datetime import datetime

from app.config import settings


@dataclass
class PeerStatus:
    public_key: str
    endpoint: str | None
    latest_handshake: datetime | None
    transfer_rx_mb: float
    transfer_tx_mb: float
    is_online: bool  # handshake был < 3 минут назад


class WireGuardError(RuntimeError):
    pass


async def _run(*cmd: str) -> str:
    proc = await asyncio.create_subprocess_exec(
        *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
    )
    stdout, stderr = await proc.communicate()
    if proc.returncode != 0:
        raise WireGuardError(f"{' '.join(cmd)} failed: {stderr.decode().strip()}")
    return stdout.decode()


async def generate_keypair() -> tuple[str, str]:
    """Возвращает (private_key, public_key)."""
    private_key = (await _run("wg", "genkey")).strip()
    proc = await asyncio.create_subprocess_exec(
        "wg", "pubkey", stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE
    )
    stdout, _ = await proc.communicate(private_key.encode())
    public_key = stdout.decode().strip()
    return private_key, public_key


async def force_resync() -> str:
    """Принудительно применяет текущий конфиг-файл на живой интерфейс.
    Полезно, если peer записан в файл, но почему-то не подхватился WireGuard'ом."""
    stripped = await _run("wg-quick", "strip", settings.wg_interface)
    proc = await asyncio.create_subprocess_exec(
        "wg", "syncconf", settings.wg_interface, "/dev/stdin",
        stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
    )
    _, stderr = await proc.communicate(stripped.encode())
    if proc.returncode != 0:
        raise WireGuardError(f"wg syncconf failed (code {proc.returncode}): {stderr.decode().strip()}")
    return await _run("wg", "show", settings.wg_interface, "dump")


async def get_wg_status() -> list[PeerStatus]:
    """Парсит `wg show <iface> dump` — по одной строке на peer."""
    raw = await _run("wg", "show", settings.wg_interface, "dump")
    lines = raw.strip().splitlines()
    peers: list[PeerStatus] = []
    now = datetime.utcnow()
    # первая строка — это сам интерфейс, пропускаем
    for line in lines[1:]:
        parts = line.split("\t")
        # public_key, preshared_key, endpoint, allowed_ips, latest_handshake, rx, tx, persistent_keepalive
        if len(parts) < 8:
            continue
        pub, _psk, endpoint, _allowed, handshake_ts, rx, tx, _keepalive = parts[:8]
        handshake = datetime.utcfromtimestamp(int(handshake_ts)) if int(handshake_ts) > 0 else None
        is_online = bool(handshake and (now - handshake).total_seconds() < 180)
        peers.append(
            PeerStatus(
                public_key=pub,
                endpoint=None if endpoint == "(none)" else endpoint,
                latest_handshake=handshake,
                transfer_rx_mb=int(rx) / 1024 / 1024,
                transfer_tx_mb=int(tx) / 1024 / 1024,
                is_online=is_online,
            )
        )
    return peers


async def _next_free_ip() -> str:
    """Находит следующий свободный IP в подсети клиентов, глядя в текущий конфиг."""
    subnet = ipaddress.ip_network(settings.wg_client_subnet)
    with open(settings.wg_config_path) as f:
        content = f.read()
    used = set(re.findall(r"AllowedIPs\s*=\s*([\d.]+)/32", content))
    for ip in subnet.hosts():
        ip_str = str(ip)
        if ip_str.endswith(".1"):  # обычно .1 — сам сервер
            continue
        if ip_str not in used:
            return ip_str
    raise WireGuardError("Нет свободных IP в подсети клиентов")


async def add_peer(label: str) -> dict:
    """Генерит ключи, дописывает peer в конфиг и применяет через `wg syncconf`.
    Возвращает данные, нужные для сборки клиентского .conf.
    """
    private_key, public_key = await generate_keypair()
    ip = await _next_free_ip()

    peer_block = (
        f"\n# {label}\n[Peer]\nPublicKey = {public_key}\nAllowedIPs = {ip}/32\n"
    )
    with open(settings.wg_config_path, "a") as f:
        f.write(peer_block)

    # применяем изменения без разрыва текущих соединений
    stripped = await _run("wg-quick", "strip", settings.wg_interface)
    proc = await asyncio.create_subprocess_exec(
        "wg", "syncconf", settings.wg_interface, "/dev/stdin",
        stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
    )
    _, stderr = await proc.communicate(stripped.encode())
    if proc.returncode != 0:
        raise WireGuardError(f"wg syncconf failed (code {proc.returncode}): {stderr.decode().strip()}")

    return {
        "private_key": private_key,
        "public_key": public_key,
        "address": f"{ip}/32",
    }


async def remove_peer(public_key: str) -> None:
    await _run("wg", "set", settings.wg_interface, "peer", public_key, "remove")

    # чистим конфиг-файл, чтобы peer не появился обратно после рестарта
    with open(settings.wg_config_path) as f:
        content = f.read()
    pattern = re.compile(
        rf"\n?# .*\n\[Peer\]\nPublicKey = {re.escape(public_key)}\n(?:.*\n)*?(?=\n\[Peer\]|\Z)"
    )
    content = pattern.sub("", content)
    with open(settings.wg_config_path, "w") as f:
        f.write(content)


async def reenable_peer(public_key: str, address: str, label: str) -> None:
    """Возвращает ранее отключённый (remove_peer) ключ обратно в строй —
    с тем же публичным ключом и IP, новый ключ не генерируется."""
    peer_block = f"\n# {label}\n[Peer]\nPublicKey = {public_key}\nAllowedIPs = {address}\n"
    with open(settings.wg_config_path, "a") as f:
        f.write(peer_block)

    stripped = await _run("wg-quick", "strip", settings.wg_interface)
    proc = await asyncio.create_subprocess_exec(
        "wg", "syncconf", settings.wg_interface, "/dev/stdin",
        stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
    )
    _, stderr = await proc.communicate(stripped.encode())
    if proc.returncode != 0:
        raise WireGuardError(f"wg syncconf failed (code {proc.returncode}): {stderr.decode().strip()}")


def build_client_config(private_key: str, address: str) -> str:
    return (
        f"[Interface]\n"
        f"PrivateKey = {private_key}\n"
        f"Address = {address}\n"
        f"DNS = {settings.wg_client_dns}\n\n"
        f"[Peer]\n"
        f"PublicKey = {settings.wg_server_public_key}\n"
        f"Endpoint = {settings.wg_server_public_endpoint}\n"
        f"AllowedIPs = 0.0.0.0/0, ::/0\n"
        f"PersistentKeepalive = 25\n"
    )


def build_qr_png(config_text: str) -> bytes:
    """Генерит PNG с QR-кодом конфига — приложение WireGuard на телефоне
    сканирует его и сразу добавляет туннель, без ручного импорта файла."""
    import io

    import qrcode

    img = qrcode.make(config_text)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()
