import httpx

from app.config import settings

BASE_URL = "https://api.timeweb.cloud/api/v1"


class TimewebClient:
    def __init__(self) -> None:
        self._headers = {"Authorization": f"Bearer {settings.timeweb_token}"}

    async def get_balance(self) -> float:
        async with httpx.AsyncClient(base_url=BASE_URL, headers=self._headers, timeout=15) as client:
            resp = await client.get("/account/finances")
            resp.raise_for_status()
            data = resp.json()
            return float(data["finances"]["balance"])

    async def get_server_info(self) -> dict:
        """Инфо о конкретном сервере (тариф, статус, IP и т.п.)."""
        async with httpx.AsyncClient(base_url=BASE_URL, headers=self._headers, timeout=15) as client:
            resp = await client.get(f"/servers/{settings.timeweb_server_id}")
            resp.raise_for_status()
            return resp.json()

    async def list_servers(self) -> list[dict]:
        async with httpx.AsyncClient(base_url=BASE_URL, headers=self._headers, timeout=15) as client:
            resp = await client.get("/servers")
            resp.raise_for_status()
            return resp.json().get("servers", [])


timeweb_client = TimewebClient()
