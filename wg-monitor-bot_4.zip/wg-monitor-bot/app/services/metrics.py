from dataclasses import dataclass
from datetime import datetime, timedelta

import psutil
from sqlalchemy import func, select

from app.database.engine import async_session
from app.database.models import ServerMetric

_last_net = psutil.net_io_counters()


async def collect_snapshot() -> None:
    """Снимает текущую нагрузку и пишет строку в БД. Вызывается планировщиком раз в минуту."""
    global _last_net

    cpu = psutil.cpu_percent(interval=1)
    mem = psutil.virtual_memory()
    disk = psutil.disk_usage("/")
    net = psutil.net_io_counters()

    sent_mb = (net.bytes_sent - _last_net.bytes_sent) / 1024 / 1024
    recv_mb = (net.bytes_recv - _last_net.bytes_recv) / 1024 / 1024
    _last_net = net

    async with async_session() as session:
        session.add(
            ServerMetric(
                cpu_percent=cpu,
                ram_percent=mem.percent,
                ram_used_mb=mem.used / 1024 / 1024,
                ram_total_mb=mem.total / 1024 / 1024,
                disk_percent=disk.percent,
                net_sent_mb=max(sent_mb, 0),
                net_recv_mb=max(recv_mb, 0),
            )
        )
        await session.commit()


@dataclass
class PeriodStats:
    label: str
    avg_cpu: float
    max_cpu: float
    avg_ram: float
    max_ram: float


PERIODS = {
    "1h": timedelta(hours=1),
    "12h": timedelta(hours=12),
    "24h": timedelta(days=1),
    "7d": timedelta(days=7),
}


async def get_period_stats() -> list[PeriodStats]:
    results = []
    async with async_session() as session:
        for label, delta in PERIODS.items():
            since = datetime.utcnow() - delta
            stmt = select(
                func.avg(ServerMetric.cpu_percent),
                func.max(ServerMetric.cpu_percent),
                func.avg(ServerMetric.ram_percent),
                func.max(ServerMetric.ram_percent),
            ).where(ServerMetric.ts >= since)
            row = (await session.execute(stmt)).one()
            avg_cpu, max_cpu, avg_ram, max_ram = row
            results.append(
                PeriodStats(
                    label=label,
                    avg_cpu=round(avg_cpu or 0, 1),
                    max_cpu=round(max_cpu or 0, 1),
                    avg_ram=round(avg_ram or 0, 1),
                    max_ram=round(max_ram or 0, 1),
                )
            )
    return results


async def get_current_snapshot() -> dict:
    cpu = psutil.cpu_percent(interval=0.5)
    mem = psutil.virtual_memory()
    disk = psutil.disk_usage("/")
    uptime_seconds = int(datetime.now().timestamp() - psutil.boot_time())
    return {
        "cpu_percent": cpu,
        "ram_percent": mem.percent,
        "ram_used_mb": round(mem.used / 1024 / 1024, 1),
        "ram_total_mb": round(mem.total / 1024 / 1024, 1),
        "disk_percent": disk.percent,
        "uptime_hours": round(uptime_seconds / 3600, 1),
    }
