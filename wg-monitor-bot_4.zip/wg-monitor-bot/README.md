# WG Monitor Bot

Telegram-бот + Mini App для мониторинга сервера на Timeweb Cloud, подключённого
через WireGuard: пинг/онлайн клиентов, нагрузка CPU/RAM (сейчас, 1ч/12ч/24ч/7д),
баланс Timeweb, выдача и отзыв WireGuard-ключей с одобрением админом.

## 1. Быстрый старт

```bash
cp .env.example .env
# заполни BOT_TOKEN, ADMIN_IDS, WG_*, TIMEWEB_TOKEN, WEBAPP_PUBLIC_URL
docker compose up -d --build
```

## 2. Права для WireGuard (важно!)

Контейнер `bot` в `docker-compose.yml` запущен с `network_mode: host` и
`cap_add: NET_ADMIN`, чтобы напрямую вызывать `wg`/`wg-quick` для существующего
интерфейса `wg0` на хосте. Это даёт контейнеру доступ ко всей сети хоста —
осознанный компромисс ради простоты.

**Альтернатива без host-режима**, если это смущает: вынести `wireguard.py` в
отдельный небольшой скрипт, который выполняется на самом хосте (не в
контейнере) от root через sudo с ограниченным NOPASSWD-правилом:

```
# /etc/sudoers.d/wgbot
wgbot ALL=(root) NOPASSWD: /usr/bin/wg, /usr/bin/wg-quick
```

а бот внутри контейнера дёргает этот скрипт по SSH или через небольшой
локальный HTTP-эндпоинт на хосте. В текущей версии проекта это не
реализовано — если хочешь такой вариант, скажи, доработаю.

## 3. Привязка домена к серверу

1. В Timeweb Cloud → раздел «Домены» либо у своего регистратора — добавь
   **A-запись**: `@` (или поддомен, например `wg.example.com`) →
   IP-адрес твоего сервера.
2. На сервере поставь nginx как reverse-proxy перед `webapp` (порт 8000) и
   certbot для HTTPS — Telegram Mini App **обязательно** требует HTTPS:

   ```bash
   sudo apt install nginx certbot python3-certbot-nginx
   ```

   Пример `/etc/nginx/sites-available/wgbot`:
   ```nginx
   server {
       server_name wg.example.com;
       location / {
           proxy_pass http://127.0.0.1:8000;
           proxy_set_header Host $host;
       }
   }
   ```
   ```bash
   sudo ln -s /etc/nginx/sites-available/wgbot /etc/nginx/sites-enabled/
   sudo certbot --nginx -d wg.example.com
   ```
3. Пропиши получившийся `https://wg.example.com` в `.env` →
   `WEBAPP_PUBLIC_URL`, перезапусти бота.
4. У @BotFather: `/mybots` → твой бот → `Bot Settings` → `Menu Button` →
   укажи тот же URL, либо просто используй кнопку, которую бот сам присылает
   в `/start` (уже реализовано в `app/bot/handlers/user.py`).

## 4. Как получить нужные значения для .env

- **ADMIN_IDS** — свой `telegram_id` узнать у @userinfobot.
- **WG_SERVER_PUBLIC_KEY** — `cat /etc/wireguard/publickey` на сервере
  (или посмотреть в текущем `wg0.conf`).
- **TIMEWEB_TOKEN** — см. инструкцию в чате / панель Timeweb Cloud →
  «API и Terraform» → «Добавить токен».
- **TIMEWEB_SERVER_ID** — `curl -H "Authorization: Bearer $TOKEN" https://api.timeweb.cloud/api/v1/servers`,
  взять `id` нужного сервера из ответа.

## 5. Что уже реализовано

- Разделение ролей admin/user (по списку `ADMIN_IDS`, авто-регистрация в БД).
- Админ: `/stats` (CPU/RAM/диск/баланс), `/peers` (кто онлайн), `/requests`
  (одобрение/отклонение заявок на ключи), ежедневный отчёт по расписанию.
- Пользователь: `/mykeys`, `/request <название>` — заявка на ключ с
  одобрением админом инлайн-кнопками, автоматическая генерация WG-ключа и
  отправка готового `.conf` после одобрения.
- Сбор метрик CPU/RAM/диска раз в минуту в БД + агрегация за 1ч/12ч/24ч/7д.
- Telegram Mini App (FastAPI + статический HTML) с теми же данными в браузере
  внутри Telegram, с валидацией `initData` по HMAC.

## 6. Что стоит доделать дальше (не реализовано в этом скелете)

- QR-код для конфига (библиотека `qrcode` уже в requirements, осталось
  прикрутить к хендлеру одобрения заявки).
- Точный эндпоинт истории нагрузки самого Timeweb Cloud (сейчас метрики
  считаются локальным сборщиком через `psutil` — это не зависит от API
  провайдера, но если хочешь именно "как в панели Timeweb" — нужно свериться
  с их Swagger по конкретному серверу).
- Алерты (например, если баланс < X ₽ или CPU > 90% дольше 5 минут).
- Отзыв ключей пользователем самостоятельно (сейчас отзыв — только руками
  через БД/`wireguard.remove_peer`, хендлера в боте под это пока нет).
